package com.cg.ofr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineFlatRentalApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineFlatRentalApplication.class, args);
	}

}
