package com.cg.ofr.exception;

public class EmptyEntityListException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmptyEntityListException(String message) {
		super(message);
	}

}
