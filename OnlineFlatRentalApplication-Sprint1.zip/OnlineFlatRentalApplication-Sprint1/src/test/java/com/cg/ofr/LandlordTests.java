package com.cg.ofr;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.ofr.entities.Flat;
import com.cg.ofr.entities.FlatAddress;
import com.cg.ofr.entities.Landlord;
import com.cg.ofr.exception.LandlordNotFoundException;
import com.cg.ofr.service.LandlordServiceImpl;

/******************************
 * @author          Y.Manideep
 * Description      It is a Landlord Test cases implementation class that tests the
 *                  CRUD Operations defined in service interface 
 * Version          1.0
 * Created Date     25-MARCH-2021
 ******************************/


@SpringBootTest
public class LandlordTests extends OnlineFlatRentalApplicationTests {
	
	@Autowired
	private LandlordServiceImpl ilandlordserviceimpl;

	/**************************
	 * Method:         addLandlordTest
     * Description:    To test the addLandlordTest Method of LandlordService
     * Created By      Y.Manideep
     * Created Date    25-MARCH-2021                           
	 ***************************/ 
	
	@Test
	public void addLandlordTest1() {
		FlatAddress flatadress = new FlatAddress(112, "velnagar", "india", "tamilnadu", 600062, "chennai");
		Flat flat = new Flat(100, 5000, flatadress, "yes");
		List<Flat> flatList = new ArrayList<Flat>();
		flatList.add(flat);
		Landlord landlord = new Landlord(17, "karthik", 45, flatList);
		ilandlordserviceimpl.addLandlord(landlord);
		assertEquals("karthik", landlord.getLandlordName());

	}

	@Test
	public void addLandlordTest2() {
		FlatAddress flatadress = new FlatAddress(113, "velnagar", "india", "tamilnadu", 600062, "chennai");
		Flat flat = new Flat(101, 5000, flatadress, "yes");
		List<Flat> flatList = new ArrayList<Flat>();
		flatList.add(flat);
		Landlord landlord = new Landlord(18, "panda", 25, flatList);
		ilandlordserviceimpl.addLandlord(landlord);
		assertEquals("panda", landlord.getLandlordName());

	}
	
	/**************************
	 * Method:         updateLandlordTest
     * Description:    To test the updateLandlordTest Method of LandlordService
     * Created By      Y.Manideep
     * Created Date    25-MARCH-2021                           
	 ***************************/ 
	
	@Test
	public void updateLandlordTest1() {
		FlatAddress flataddress = new FlatAddress(114, "velnagar", "india", "tamilnadu", 600062, "chennai");
		Flat flat = new Flat(102, 5000, flataddress, "No");
		List<Flat> flatlist = new ArrayList<Flat>();
		flatlist.add(flat);
		Landlord landlord = new Landlord(19, "anil", 25, flatlist);
		landlord.setLandlordName("suresh");
		ilandlordserviceimpl.updateLandlord(landlord);
		assertEquals("suresh", landlord.getLandlordName());

	}

	@Test
	public void updateLandlordTest2() {
		FlatAddress flatadress = new FlatAddress(115, "velnagar", "india", "tamilnadu", 600062, "chennai");
		Flat flat = new Flat(103, 5000, flatadress, "No");
		List<Flat> flatlist = new ArrayList<Flat>();
		flatlist.add(flat);
		Landlord landlord = new Landlord(7, "sunil", 25, flatlist);
		landlord.setLandlordAge(40);
		ilandlordserviceimpl.updateLandlord(landlord);
		assertEquals(40, landlord.getLandlordAge());

	}
	
	/**************************
	 * Method:         deleteLandlordTest
     * Description:    To test the deleteLandlordTest Method of LandlordService
     * Created By      Y.Manideep
     * Created Date    25-MARCH-2021                           
	 ***************************/ 
	
	@Test
	public void deleteLandlordTest1() {
		FlatAddress flatadress = new FlatAddress(116, "velnagar", "india", "tamilnadu", 600062, "chennai");
		Flat flat = new Flat(104, 5000, flatadress, "No");
		List<Flat> flatlist = new ArrayList<Flat>();
		flatlist.add(flat);
		Landlord landlord = new Landlord(20, "kishore", 25, flatlist);
		ilandlordserviceimpl.addLandlord(landlord);
		Landlord landlord1 = ilandlordserviceimpl.deleteLandlord(landlord);
		assertEquals("kishore", landlord1.getLandlordName());
	}

	@Test
	public void deleteLandlordTest2() {
		FlatAddress flatadress = new FlatAddress(117, "velnagar", "india", "tamilnadu", 600062, "chennai");
		Flat flat = new Flat(105, 5000, flatadress, "No");
		List<Flat> flatlist = new ArrayList<Flat>();
		flatlist.add(flat);
		Landlord landlord = new Landlord(9, "rakesh", 25, flatlist);
		ilandlordserviceimpl.addLandlord(landlord);
		Landlord landlord1 = ilandlordserviceimpl.deleteLandlord(landlord);
		assertEquals("rakesh", landlord1.getLandlordName());

	}
	
	/**************************
	 * Method:         viewLandlordTest
     * Description:    To test the viewLandlordTest Method of LandlordService
     * Created By      Y.Manideep
     * Created Date    25-MARCH-2021                           
	 ***************************/ 
	
	@Test
	public void viewLandlordTest1() throws LandlordNotFoundException {
		assertNotNull(ilandlordserviceimpl.viewLandlord(17));
	}
	
	@Test
	public void viewLandlordTest2() throws LandlordNotFoundException {
		assertNotNull(ilandlordserviceimpl.viewLandlord(18));
	}
	
	/**************************
	 * Method:         viewAllLandlordTest
     * Description:    To test the viewAllLandlordTest Method of LandlordService
     * Created By      Y.Manideep
     * Created Date    25-MARCH-2021                           
	 ***************************/ 
	
	@Test
	public void viewAllLandlordTest() {
		assertNotNull(ilandlordserviceimpl.viewAllLandlord());
	}
	
}