package com.cg.ofr;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.ofr.entities.Flat;
import com.cg.ofr.entities.FlatAddress;
import com.cg.ofr.entities.FlatBooking;
import com.cg.ofr.entities.Tenant;
import com.cg.ofr.exception.TenantNotFoundException;
import com.cg.ofr.service.ITenantService;

@SpringBootTest
public class TenantTests extends OnlineFlatRentalApplicationTests {
	
	/****
	 *          @author          E.Jagadeesh
	 *          Description      It is a Tenant Test cases implementation class that tests the
	 *                              CRUD Operations defined in service interface
	 *             
	  *         Version             1.0
	  *         Created Date    25-MARCH-2021
	 ****/

	@Autowired
	ITenantService itenantService;

	FlatAddress flatAddress11 = new FlatAddress(211, "Golden street", "Ongole", "Andhra Pradesh", 523001, "India");
	Flat flat11 = new Flat(11, 100000, flatAddress11, "yes");
	FlatBooking flatBooking11 = new FlatBooking(111, LocalDate.of(2015, 11, 21), LocalDate.of(2020, 11, 21), flat11,
			null);
	Tenant tenant11 = new Tenant(11, 41, flatBooking11);

	FlatAddress flatAddress12 = new FlatAddress(212, "French street", "Vijayawada", "Andhra Pradesh", 52441, "India");
	Flat flat12 = new Flat(12, 200000, flatAddress12, "yes");
	FlatBooking flatBooking12 = new FlatBooking(112, LocalDate.of(2015, 11, 21), LocalDate.of(2020, 11, 21), flat12,
			null);
	Tenant tenant12 = new Tenant(12, 42, flatBooking12);

	FlatAddress flatAddress13 = new FlatAddress(213, "Court street", "Vizag", "Andhra Pradesh", 524321, "India");
	Flat flat13 = new Flat(13, 400000, flatAddress13, "yes");
	FlatBooking flatBooking13 = new FlatBooking(146, LocalDate.of(2015, 11, 21), LocalDate.of(2020, 11, 21), flat13,
			null);
	Tenant tenant13 = new Tenant(13, 43, flatBooking13);
	
	/****
	 * Method:        addTenantTest
     *Description:    To test the addTenantTest Method of TenantService
     *Created By    - E.Jagadeesh
     *Created Date  - 25-MARCH-2021                           
	 
	 ****/

	@Test
	@DisplayName("add tenant11 should work")
	void addTenantTest1() {
		assertEquals(100000, flat11.getCost());
		System.out.println("Successfully tenant is added");
	}

	@Test
	@DisplayName("add tenant12 should work")
	void addTenantTest2() {
		assertNotNull(tenant11.getTenantId());
		System.out.println("Successfully tenant is added");
	}

	/****
	 * Method:        updateTenantTest
     *Description:    To test the updateTenantTest Method of TenantService
     *Created By    - E.Jagadeesh
     *Created Date  - 25-MARCH-2021                           
	 
	 ****/
	
	@Test
	@DisplayName("update tenant11 should work")
	void updateTenantTest1() {
		itenantService.addTenant(tenant11);
		tenant11.setAge(44);
		itenantService.updateTenant(tenant11);
		assertEquals(44, tenant11.getAge());
		System.out.println("Successfully tenant is updated");
	}

	@Test
	@DisplayName("update tenant12 should work")
	void updateTenantTest2() {
		itenantService.addTenant(tenant12);
		flat12.setCost(300000);
		itenantService.updateTenant(tenant12);
		assertEquals(300000, flat12.getCost());
		System.out.println("Successfully tenant is updated");
	}

	/****
	 * Method:        deleteTenantTest
     *Description:    To test the deleteTenantTest Method of TenantService
     *Created By    - E.Jagadeesh
     *Created Date  - 25-MARCH-2021                           
	 
	 ****/
	
	@Test
	@DisplayName("delete tenant11 should work")
	void deleteTenantTest1() {
		itenantService.addTenant(tenant11);
		Tenant removeTenant1 = itenantService.deleteTenant(tenant11);
		assertEquals(11, removeTenant1.getTenantId());
		System.out.println("Successfully tenant is deleted");
	}

	@Test
	@DisplayName("delete tenant13 should work")
	void deleteTenantTest2() {
		itenantService.addTenant(tenant13);
		Tenant removeTenant2 = itenantService.deleteTenant(tenant13);
		assertEquals(43, removeTenant2.getAge());
		itenantService.deleteTenant(tenant12);
		System.out.println("Successfully tenant is deleted");
	}
	
	/****
	 * Method:        viewTenantTest
     *Description:    To test the viewTenantTest Method of TenantService
     *Created By    - E.Jagadeesh
     *Created Date  - 25-MARCH-2021                           
	 
	 ****/

	@Test
	@DisplayName("view tenant should work")
	void viewTenanTest() throws TenantNotFoundException {
}
	@Test
	@DisplayName("view tenant12 should work")
	void viewTenanTest12() throws TenantNotFoundException {
		Tenant tenant = itenantService.viewTenant(tenant12.getTenantId());
		assertEquals(tenant12.getTenantId(), tenant.getTenantId());
	}

	/****
	 * Method:        viewAllTenantTest
     *Description:    To test the viewAllTenantTest Method of TenantService
     *Created By    - E.Jagadeesh
     *Created Date  - 25-MARCH-2021                           
	 
	 ****/
	@Test
	@DisplayName("view all tenant should work")
	void viewAllTenanTest() {
		List<Tenant> list = itenantService.viewAllTenant();
		assertNotNull(list);
	}

}